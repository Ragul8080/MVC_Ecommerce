﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations.Schema;

namespace EcoomerceApp.Models.Entity
{
    public class ShoppingCart
    {
        public int Id { get; set; } 
        public int ProductId { get; set; }

        public string ApplicationUserId { get; set; }
    }
}
