﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EcoomerceApp.Models.Entity

{
    public class OrderDetail
    {
        public int Id { get; set; }
        [Required]

        public OrderHeader OrderHeader { get; set; }
        public int OrderId { get; set; }
        [ForeignKey("OrderId")]
        [ValidateNever]
        public int ProductId { get; set; }

        public int Count { get; set; }

    }
}
