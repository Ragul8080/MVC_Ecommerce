﻿using EcoomerceApp.Models.Entity;
using Microsoft.EntityFrameworkCore;
namespace EcoomerceApp.Data
{
    public class EcommerceContext : DbContext
    {
        public EcommerceContext(DbContextOptions<EcommerceContext> options):base(options) 
        {
        }

        public DbSet<ApplicationUser> T_applicationUsers { get; set; }
        public DbSet<Product> T_products { get; set; }

        public DbSet<Category> T_categories { get; set; }

        public DbSet<ShoppingCart> T_shoppingCarts { get; set; }

        public DbSet<OrderHeader> T_orderHeaders { get; set; }

        public DbSet<OrderDetail> T_orderDetail { get; set; }

       
    }
}
